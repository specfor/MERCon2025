$(function(){
    $("header").load("nav.html");
    $("footer").load("footer.html");
  });